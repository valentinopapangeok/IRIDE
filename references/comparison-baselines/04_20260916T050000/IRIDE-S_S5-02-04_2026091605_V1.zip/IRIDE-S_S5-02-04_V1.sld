<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" version="1.0.0" xmlns:sld="http://www.opengis.net/sld" xmlns:gml="http://www.opengis.net/gml">
  <UserLayer>
    <sld:LayerFeatureConstraints>
      <sld:FeatureTypeConstraint/>
    </sld:LayerFeatureConstraints>
    <sld:UserStyle>
      <sld:Name>Precipitation amount</sld:Name>
      <sld:FeatureTypeStyle>
        <sld:Rule>
          <sld:RasterSymbolizer>
            <sld:ChannelSelection>
              <sld:GrayChannel>
                <sld:SourceChannelName>1</sld:SourceChannelName>
              </sld:GrayChannel>
            </sld:ChannelSelection>
            <sld:ColorMap type="ramp">
			  <sld:ColorMapEntry quantity="-999" label="No Data" color="#000000" opacity="0"/>
              <sld:ColorMapEntry color="#f7fbff" label="0.0 mm" quantity="0"/>
              <sld:ColorMapEntry color="#deebf7" label="1.3" quantity="1.3"/>
              <sld:ColorMapEntry color="#c6dbef" label="2.6" quantity="2.6000000000000001"/>
              <sld:ColorMapEntry color="#9ecae1" label="3.9" quantity="3.9000000000000004"/>
              <sld:ColorMapEntry color="#6baed6" label="5.2" quantity="5.2000000000000002"/>
              <sld:ColorMapEntry color="#4292c6" label="6.5" quantity="6.5"/>
              <sld:ColorMapEntry color="#2171b5" label="7.8" quantity="7.8000000000000007"/>
              <sld:ColorMapEntry color="#08519c" label="9.0" quantity="9"/>
              <sld:ColorMapEntry color="#08306b" label="10.0" quantity="10"/>
            </sld:ColorMap>
          </sld:RasterSymbolizer>
        </sld:Rule>
      </sld:FeatureTypeStyle>
    </sld:UserStyle>
  </UserLayer>
</StyledLayerDescriptor>
